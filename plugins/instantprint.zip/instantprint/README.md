Instant Print plugin for QGIS
=============================

The instant print plugin allows to quickly print map excerpts to a file, utilizing an existing composer as page layout.

![screenshot](help/img/screenshot.png)
